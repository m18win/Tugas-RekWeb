<?php

	if (isset($_GET['angka'])) {
 		$angka = $_GET['angka'];
	} else {
		$angka = 0;
	}

?>

<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		.kotaka {
			border: 1px solid black;
			background-color: aqua;
			width: 22px;
			height: 22px;
			display: inline-block;
			margin: 2px;
			text-align: center;
		}
		.kotakb {
			border: 1px solid black;
			background-color: yellow;
			width: 22px;
			height: 22px;
			display: inline-block;
			margin: 2px;
			text-align: center;
		}
	</style>
	<title>Latihan 5A</title>
</head>
<body>
<?php
	for ($a=$angka; $a >= 0; $a--) { 
		for ($b=0; $b < $a; $b++) { 
			if ($a % 2 == 0) {
				echo "<div class='kotaka'>$a</div>";
			} else {
				echo "<div class='kotakb'>$a</div>";
			}
		}
		echo "<br>";
	}
?>
</body>
</html>