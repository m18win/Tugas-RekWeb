<?php 

$peralatan = [
					[
					"gambar" => "Lampu.jpg",
					"nama" => "Lampu LED Anti Nyamuk - 9 watt",
					"jenis" => "Lampu",
					"merek" => "Hannochs",
					"harga" => "63.000"],

					[
					"gambar" => "Kompor.jpg",
					"nama" => "Rinnai Gas Stove RI-522S-Black",
					"jenis" => "Kompor",
					"merek" => "Rinnai",
					"harga" => "249.000"],

					[
					"gambar" => "Kulkas.jpg",
					"nama" => "KULKAS 2 PINTU SAMSUNG RT38K5032S8 Twin Cooling 384 LITER",
					"jenis" => "Kulkas",
					"merek" => "Samsung",
					"harga" => "5.999.000"],

					[
					"gambar" => "Blender.jpg",
					"nama" => "Blender Plastik Cosmos Stainless Steel 3in1 2 liter CB-282P CB282P",
					"jenis" => "Blender",
					"merek" => "Cosmos",
					"harga" => "265.000"],

					[
					"gambar" => "Vacuum.jpg",
					"nama" => "VC 2050 Vacuum Cleaner",
					"jenis" => "Vacuum (Pembersih Debu)",
					"merek" => "Modena",
					"harga" => "1.422.000"],

					[
					"gambar" => "Rice Cooker.jpg",
					"nama" => "Rice Cooker Philips HD3127",
					"jenis" => "Rice Cooker (Pemasak Nasi)",
					"merek" => "Philips",
					"harga" => "450.000"],

					[
					"gambar" => "Kipas Angin.jpg",
					"nama" => "KRISBOW Ventilator Fan",
					"jenis" => "Kipas Angin",
					"merek" => "Krisbow",
					"harga" => "2.190.000"],

					[
					"gambar" => "Telepon Kabel.jpeg",
					"nama" => "Panasonic Telephone KX-TS505",
					"jenis" => "Telepon Kabel",
					"merek" => "Panasonic",
					"harga" => "149.000"],

					[
					"gambar" => "Radio.jpg",
					"nama" => "Radio Klasik International F 18 Model Jadul AM FM Portable Radio",
					"jenis" => "Radio",
					"merek" => "International",
					"harga" => "85.000"],

					[
					"gambar" => "Mesin Cuci.jpg",
					"nama" => "Sharp ES-FL862 Mesin Cuci Front Loading Boomerang Series",
					"jenis" => "Mesin Cuci",
					"merek" => "Sharp",
					"harga" => "3.082.500"]
				]

?>

<!DOCTYPE html>
<html>
<head>
	<title>Latihan 5B</title>
</head>
<body bgcolor="aqua">
	<h1>Macam-macam Peralatan Elektronik</h1>
	<ul>
		<?php foreach ($peralatan as $per) : ?>
			<li>
				<a href="../latihan5c/latihan5c.php?gambar=<?= $per['gambar']; ?>&nama=<?= $per['nama'];?>&jenis=<?= $per['jenis'];?>&merek=<?= $per['merek'];?>&harga=<?= $per['harga'];?>"><?= $per['nama'] ?></a>
			</li>
		<?php endforeach; ?>
	</ul>
</body>
</html>