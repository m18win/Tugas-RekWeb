<!DOCTYPE html>
<html>
<head>
	<title>Latihan 5C</title>
</head>
<body bgcolor="aqua">
	<table align="center" border="1" cellspacing="0" cellpadding="10">
		<tr>
			<th bgcolor="lightgreen">Foto</th>
			<th bgcolor="lightgreen">Nama</th>
			<th bgcolor="lightgreen">Jenis</th>
			<th bgcolor="lightgreen">Merek</th>
			<th bgcolor="lightgreen">Harga</th>
		</tr>
		<tr>
			<td bgcolor="white"><img src="../img/<?php echo $_GET['gambar']?>" width="100px"></td>
			<td bgcolor="white"><?php echo $_GET['nama']?></td>
			<td bgcolor="white"><?php echo $_GET['jenis']?></td>
			<td bgcolor="white"><?php echo $_GET['merek']?></td>
			<td bgcolor="white"><?php echo $_GET['harga']?></td>
		</tr>
	</table>
	<br>
	<div align="center"><a href="../latihan5b/latihan5b.php"><button>Kembali ke Latihan5B</button></a></div>
</body>
</html>