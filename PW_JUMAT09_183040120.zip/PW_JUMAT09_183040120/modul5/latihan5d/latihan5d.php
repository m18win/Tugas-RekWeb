<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		.kotaka {
			border: 1px solid black;
			background-color: sykblue;
			width: 22px;
			height: 22px;
			display: inline-block;
			margin: 2px;
			text-align: center;
		}
		.kotakb {
			border: 1px solid black;
			background-color: lightgreen;
			width: 22px;
			height: 22px;
			display: inline-block;
			margin: 2px;
			text-align: center;
		}
	</style>
	<title>Latihan 5D</title>
</head>
<body>
	<form action="latihan5d.php" method="post">
		<label for="name">Masukan Angka : </label>
		<input type="text" name="angka">
		<br>
		<button type="submit" name="submit">Kirim</button>
		<hr>
	</form>

	<?php  
		if (isset($_POST['angka'])) {
 			$angka = $_POST['angka'];
		} else {
			$angka = 0;
		}
	?>

	<?php  
		for ($a=$angka; $a >= 1; $a--) { 
			for ($b=$a; $b >= 1; $b--) { 
				if ($a % 2 == 0) {
					echo "<div class='kotaka'>$a</div>";
				} else {
					echo "<div class='kotakb'>$a</div>";
				}
			}
			echo "<br>";
		}
	?>
</body>
</html>