<?php  

$error = '';

if (isset($_POST['submit'])) {
	if ($_POST['username'] == 'admin' && $_POST['password'] == 'admin') {
		header('Location: admin.php');
	} else {
		$error = 'Username / Password Salah!';
	}	
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body align="center">
	<h1>Login Admin</h1>
	<form action="" method="post">
		<?php if (isset($error)) {
			echo $error;
			$error = '';
		} 
		?>
		<br>
		<p>Username</p><input type="text" name="username">
		<br>
		<p>Password</p><input type="password" name="password">
		<br><br>
		<button type="submit" name="submit">Login</button>
	</form>
		<br>
		<p>Notes : Username = admin , Password = admin</p>
</body>
</html>