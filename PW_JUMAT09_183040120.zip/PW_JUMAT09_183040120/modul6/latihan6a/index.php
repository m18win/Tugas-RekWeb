<?php 
$conn = mysqli_connect("localhost","root","") or die("Connection to DB failed!");
mysqli_select_db($conn, "pwtubes120") or die("Wrong Database!");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Latihan 6A</title>
</head>
<body bgcolor="aqua">
	<div class="container">
		<?php
			$results = mysqli_query($conn,"SELECT * FROM printer");
			While($per = mysqli_fetch_assoc($results)) {
		?>
			<div class="content" align="center">
				<div class="gambar">
					<img src="../img/<?= $per['gambar'] ?>" width="100px">
				</div>
				<p><?= $per['kode_pr'] ?></p>
				<p><?= $per['nama_pr'] ?></p>
				<p><?= $per['merk_pr'] ?></p>
				<p><?= $per['jenis_pr'] ?></p>
				<p><?= $per['harga_pr'] ?></p>
				<p><?= $per['gambar_pr'] ?></p>
			</div>
		<?php } ?>
	</div>
</body>
</html>