<?php  

function connection() {
	$conn = mysqli_connect("localhost","root","") or die("Connection to DB failed!");
	mysqli_select_db($conn, "pwtubes120") or die("Wrong Database!");

	return $conn;
}

function query($sql) {
	$conn = connection();
	$results = mysqli_query($conn, "$sql");

	$rows = [];
	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	};

	return $rows;
}

?>