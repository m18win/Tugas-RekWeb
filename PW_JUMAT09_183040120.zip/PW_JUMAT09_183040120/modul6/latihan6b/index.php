<?php 
	$conn = mysqli_connect("localhost","root","") or die("Connection to DB failed!");
	mysqli_select_db($conn, "pwtubes120") or die("Wrong Database!");
?>

<?php
	require 'functions.php';
	$printer = mysqli_query($conn,"SELECT * FROM printer");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Latihan 6B</title>
</head>
<body bgcolor="aqua">
	<div class="container">
		<?php foreach ($printer as $prn) : ?>
		<div class="content" align="center">
			<div class="gambar">
				<img src="../img/<?= $prn['gambar'] ?>" width="100px">
			</div>
			<p><?= $prn['kode_pr'] ?></p>
			<p><?= $prn['nama_pr'] ?></p>
			<p><?= $prn['merk_pr'] ?></p>
			<p><?= $prn['jenis_pr'] ?></p>
			<p><?= $prn['harga_pr'] ?></p>
			<p><?= $prn['gambar_pr'] ?></p>
		</div>
		<?php endforeach; ?>
	</div>
</body>
</html>