<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
</head>
<body bgcolor="aqua">
	<table align="center" border="1" cellspacing="0" cellpadding="10">
		<tr>
			<th>Kode</th>
			<th>Nama</th>
			<th>Merk</th>
			<th>Jenis</th>
			<th>Harga</th>
			<th>Gambar</th>
		</tr>
		
		<tr>
			<td><?= $_GET['kode_pr']; ?></td>
			<td><?= $_GET['nama_pr']; ?></td>
			<td><?= $_GET['merek_pr']; ?></td>
			<td><?= $_GET['jenis_pr']; ?></td>
			<td><?= $_GET['harga_pr']; ?></td>
			<td><img src="img/<?= $_GET['gambar']; ?>"></td>
		</tr>
	</table>
	<form method="post">
	<br>
	<div align="center"><a href="index.php"><button>Kembali</button></a></div>
	</form>
</body>
</html>