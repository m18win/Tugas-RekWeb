<?php 
	$conn = mysqli_connect("localhost","root","") or die("Connection to DB failed!");
	mysqli_select_db($conn, "pwtubes120") or die("Wrong Database!");
?>

<?php
	require 'functions.php';
	$printer = mysqli_query($conn,"SELECT * FROM printer");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Latihan 6C</title>
</head>
<body bgcolor="lightblue">
	<div class="container">
		<?php foreach ($printer as $prn) : ?>
		<div class="content" align="center">
			<div class="gambar">
				<img src="../img/<?= $prn['gambar'] ?>" width="100px">
			</div>
			<a href="profile.php?id=<?php echo $prn['id'] ?>"><?= $prn['nama_pr'] ?></a>
		</div>
		<?php endforeach; ?>
	</div>
</body>
</html>