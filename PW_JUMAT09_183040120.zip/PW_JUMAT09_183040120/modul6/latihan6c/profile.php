<?php 

if (!isset($_GET['id'])) {
	header("Location: index.php");
	exit;
}

require 'functions.php';
$id = $_GET['id'];

$per = query("SELECT * FROM printer WHERE kode_pr = '$kode'")[0];

?>

<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
</head>
<body bgcolor="aqua">
	<table align="center" border="1" cellspacing="0" cellpadding="10">
		<tr>
			<td bgcolor="white"><?php echo $prn['kode_pr']?></td>
			<td bgcolor="white"><?php echo $prn['nama_pr']?></td>
			<td bgcolor="white"><?php echo $prn['jenis_pr']?></td>
			<td bgcolor="white"><?php echo $prn['merek_pr']?></td>
			<td bgcolor="white"><?php echo $prn['harga_pr']?></td>
			<td bgcolor="white"><img src="../img/<?php echo $prn['gambar_pr']?>" width="100px"></td>
		</tr>
	</table>
	<br>
	<div align="center"><a href="index.php"><button>Kembali</button></a></div>
</body>
</html>