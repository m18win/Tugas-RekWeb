<?php

function connection() {
	$conn = mysqli_connect("localhost","root","") or die("Connection to DB failed!");
	mysqli_select_db($conn, "pwtubes120") or die("Wrong Database!");

	return $conn;
}

function query($sql) {
	$conn = connection();
	$results = mysqli_query($conn, "$sql");

	$rows = [];
	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	};

	return $rows;
}

function plus($data){
	global $conn;

	$kode_pr = htmlspecialchars($data['kode_pr']);
	$nama_pr = htmlspecialchars($data['nama_pr']);
	$merk_pr = htmlspecialchars($data['merk_pr']);
	$jenis_pr = htmlspecialchars($data['jenis_pr']);
	$harga_pr = htmlspecialchars($data['harga_pr']);
	$gambar_pr = htmlspecialchars($data['gambar_pr']);

	$query = "INSERT INTO printer VALUES('$kode_pr','$nama_pr','$merk_pr','$jenis_pr','$harga_pr', '$gambar_pr')";

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function delete($kode_pr) {
	global $conn;
	mysqli_query($conn, "DELETE FROM printer WHERE kode_pr = $kode_pr");
	
	return mysqli_affected_rows($conn);
}


function update($data) {
	global $conn;
	
	$kode_pr = htmlspecialchars($data["kode_pr"]);
	$gambar_pr = htmlspecialchars($data["gambar_pr"]);
	$nama_pr = htmlspecialchars($data["nama_pr"]);
	$jenis_pr = htmlspecialchars($data["jenis_pr"]);
	$merk_pr = htmlspecialchars($data["merk_pr"]);
	$harga_pr = htmlspecialchars($data["harga_pr"]);
	
	$query = "UPDATE printer SET 
				kode_pr = '$kode_pr',
				nama_pr = '$nama_pr',
				jenis_pr = '$jenis_pr',
				merk_pr = '$merk_pr',
				harga_pr = '$harga_pr',
				gambar_pr = '$gambar_pr'
			 WHERE kode_pr = '$kode_pr'";
	mysqli_query($conn, $query);
	
	return mysqli_affected_rows($conn);
}

function search($keyword) {
	$query = "SELECT * FROM peralatan_elektronik WHERE
				kode_pr LIKE '%$keyword%' OR
				nama_pr LIKE '%$keyword%' OR
				merk_pr LIKE '%$keyword%' OR
				jenis_pr LIKE '%$keyword%' OR
				harga_pr LIKE '%$keyword%'";
	return query($query);
}

?>