<?php

require '../assets/fonts/functions.php';

$kode_pr = $_GET["kode_pr"];
if(delete($kode_pr) > 0 ) {
		print "
			<script>
				alert('Data berhasil dihapus!');
				document.location.href = 'index.php';
			</script>
		";
	}else{
		print "
			<script>
				alert('Data gagal dihapus!');
				document.location.href = 'index.php';
			</script>
		";
	}

?>