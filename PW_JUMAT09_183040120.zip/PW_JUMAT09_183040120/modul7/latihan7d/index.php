<?php  
	require '../assets/fonts/functions.php';

	$printer = query("SELECT * FROM printer");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Latihan 7D</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/style.css">
</head>
<body>
	<h1>Macam-macam Printer</h1>
	<p><a href="plus.php">Menambah Data</a></p>
		<table border="4" cellpadding="9" cellspacing="1" bgcolor="white" width="75%">
			<tr width="25%" align="center">
				<th><h2>No</h2></th>
				<th><h2>Aksi</h2></th>
				<th><h2>Kode</h2></th>
				<th><h2>Nama</h2></th>
				<th><h2>Merk</h2></th>
				<th><h2>Jenis</h2></th>
				<th><h2>Harga</h2></th>
				<th><h2>Gambar</h2></th>
			</tr>
				<?php $no = 1; ?>
				<?php foreach ($printer as $prn): ?>
			<tr>
				<td align ="center"><?php echo $no++; ?></td>
				<td>
					<a href="update.php?kode_pr=<?=$per['kode_pr'];?>">Edit</a>
					<a href="delete.php?kode_pr=<?=$per['kode_pr'];?>" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
				</td>
				<td align ="center"><?php echo $prn["kode_pr"] ?></td>
				<td align ="center"><?php echo $prn["nama_pr"] ?></td>
				<td align ="center"><?php echo $prn["merk_pr"] ?></td>
				<td align ="center"><?php echo $prn["jenis_pr"] ?></td>
				<td align ="center"><?php echo $prn["harga_pr"] ?></td>
				<td align ="center"><?php echo $prn["gambar_pr"] ?></td>
			</tr>
		<?php endforeach ?>
		</table>
</body>
</html>