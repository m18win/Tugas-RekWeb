<?php  

require '../assets/fonts/functions.php';

if (isset($_POST["submit"])){
    if (plus($_POST) > 0){
        echo "<script>
                alert('Data berhasil ditambah!'); 
                document.location.href = 'index.php';
            </script>";
    }else{
        echo"<script>
                alert('Data gagal ditambah!');
                document.location.href = 'index.php';
            </script>";
    }
}

?>
<!DOCTYPE html>
<html>
<head>
  <title>Plus</title>
</head>
<body>
  <h1>Menambah Data</h1>
    <div>
      <form action="" method="post">
        <div>
        	<div>
                <label for="kode_pr">Kode</label><br>
                <input type="text" name="kode_pr" id="kode_pr"><br><br>
            </div>
            <div>
                <label for="nama_pr">Nama</label><br>
                <input type="text" name="nama_pr" id="nama_pr"><br><br>
            </div>
            <div>
                <label for="merk_pr">Merk</label><br>
                <input type="text" name="merk_pr" id="merk_pr"><br><br>
            </div>
            <div>
                <label for="jenis_pr">Jenis</label><br>
                <input type="text" name="jenis_pr" id="jenis_pr"><br><br>
            </div>
            <div>
                <label for="harga_pr">Harga</label><br>
                <input type="text" name="harga_pr" id="harga_pr"><br><br>
            </div>
            <div>
                <label for="gambar_pr">Gambar</label><br>
                <input type="text" name="gambar_pr" id="gambar_pr"><br><br>
            </div>
            <button type="submit" name="send">Send</button>
            <button><a href="index.php">Kembali</a></button>
        </div>
      </form>
    </div>
</body>
</html>