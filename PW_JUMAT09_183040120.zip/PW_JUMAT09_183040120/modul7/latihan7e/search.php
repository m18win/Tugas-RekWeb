<?php

require '../assets/fonts/functions.php';

if(isset($_GET['search'])) {
    $keyword = $_GET['s'];
    $peralatan = query("SELECT * FROM printer WHERE
    			kode_pr LIKE '%$keyword%' OR
				nama_pr LIKE '%$keyword%' OR
				jenis_pr LIKE '%$keyword%' OR
				merek_pr LIKE '%$keyword%' OR
				harga_pr LIKE '%$keyword%'");
    }else{
    $peralatan = query("SELECT * FROM printer");
    }
?>