<?php

require '../assets/fonts/functions.php';

$kode_pr = $_GET["kode_pr"];
$per = query("SELECT * FROM printer WHERE kode_pr = $kode_pr")[0];

if(isset($_POST['submit'])){
    if(update($_POST) > 0 ){
        print "<script>
            alert('Data berhasil diupdate!');
            document.location.href = 'index.php';
            </script>";
    }else{
        print "<script>
            alert('Data gagal diupdate!');
            document.location.href = 'index.php';
            </script>";
    }
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Update</title>
</head>
<body>
	<h1>Mengubah Data</h1>
    <form action="" method="post">
        <input type="hidden" name="id" value="<?=$per["id"];?>">

        <label for="kode_pr">Kode : </label><br>
        <input type="text" name="kode_pr" id="kode_pr" value="<?=$prn['kode_pr'];?>" required><br>

        <label for="nama_pr">Nama : </label><br>
        <input type="text" name="nama_pr" id="nama_pr" value="<?=$prn['nama_pr'];?>" required><br>

        <label for="merk_pr">Merk : </label><br>
        <input type="text" name="merk_pr" id="merk_pr" value="<?=$prn['merk_pr'];?>" required><br>

        <label for="jenis_pr">Jenis : </label><br>
        <input type="textarea" name="jenis_pr" id="jenis_pr" value="<?=$prn['jenis_pr'];?>" required><br>

        <label for="harga_pr">Harga : </label><br>
        <input type="text" name="harga_pr" id="harga_pr" value="<?=$prn['harga_pr'];?>" required><br>

        <label for="gambar_pr">Gambar : </label><br>
        <input type="text" name="gambar_pr" id="gambar_pr" value="<?=$prn['gambar_pr'];?>" required><br><br>
        <button type="submit" name="submit">Perbaharui</button>
    </form>
</body>
</html>