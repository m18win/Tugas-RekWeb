<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Admin</title>
	<style type="text/css">
		h1 {color: white;}
	</style>
</head>
<body align="center" bgcolor="salmon" color="white">
	<h1>Welcome Aswin</h1>
	<a href="index.php"><button>Menu</button></a><br><br>
	<a href="php.php"><button>Keluar</button></a>
</body>
</html>