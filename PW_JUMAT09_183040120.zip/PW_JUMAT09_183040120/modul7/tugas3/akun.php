<?php
if(isset($_POST["submit"])){
    if($_POST["username"] == "admin" && $_POST["password"] == "admin"){
        header("Location: admin.php");
        exit;
    }else{
        $error = true;
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Akun</title>
        <style>
        body    {text-align:center;}
        button  {margin-top:10px;}
        input   {margin:5px;}
        </style>
    </head>
    <body bgcolor="lightblue">
        <h1>Login Admin</h1>
        <?php if(isset($error)){?>
        <p style="color:red;"></i>Username/Password Salah!<i></p>
        <?php } ?>
        <form action="" method="post">
            <input type="text" name="username" placeholder="username"><br>
            <input type="password" name="password" placeholder="password" ><br>
            <button type="submit" name="submit">Login</button>
        </form>

    </body>
</html>