<?php

require 'functions.php';

$id = $_GET["id"];
if(delete($id) > 0 ) {
		print "
			<script>
				alert('Data berhasil dihapus!');
				document.location.href = 'index.php';
			</script>
		";
	}else{
		print "
			<script>
				alert('Data gagal dihapus!');
				document.location.href = 'index.php';
			</script>
		";
	}

?>