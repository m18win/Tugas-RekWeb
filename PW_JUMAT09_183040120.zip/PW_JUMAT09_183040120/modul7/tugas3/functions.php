<?php

function connection() {
	$conn = mysqli_connect("localhost","root","") or die("Connection to DB failed!");
	mysqli_select_db($conn, "pw_nrp") or die("Wrong Database!");

	return $conn;
}

function query($sql) {
	$conn = connection();
	$results = mysqli_query($conn, "$sql");

	$rows = [];
	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	};

	return $rows;
}

function plus($data){
	global $conn;

	$gambar = htmlspecialchars($data['gambar']);
	$nama = htmlspecialchars($data['nama']);
	$jenis = htmlspecialchars($data['jenis']);
	$merek = htmlspecialchars($data['merek']);
	$harga = htmlspecialchars($data['harga']);

	$query = "INSERT INTO peralatan_elektronik VALUES('','$gambar','$nama','$jenis','$merek','$harga')";

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function delete($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM peralatan_elektronik WHERE id = $id");
	
	return mysqli_affected_rows($conn);
}


function update($data) {
	global $conn;
	
	$id = $data["id"];
	$gambar = htmlspecialchars($data["gambar"]);
	$nama = htmlspecialchars($data["nama"]);
	$jenis = htmlspecialchars($data["jenis"]);
	$merek = htmlspecialchars($data["merek"]);
	$harga = htmlspecialchars($data["harga"]);
	
	$query = "UPDATE peralatan_elektronik SET 
				gambar = '$gambar',
				nama = '$nama',
				jenis = '$jenis',
				merek = '$merek',
				harga = '$harga'
			 WHERE id = $id";
	mysqli_query($conn, $query);
	
	return mysqli_affected_rows($conn);
}

function search($keyword) {
	$query = "SELECT * FROM peralatan_elektronik WHERE
				nama LIKE '%$keyword%' OR
				jenis LIKE '%$keyword%' OR
				merek LIKE '%$keyword%' OR
				harga LIKE '%$keyword%'";
	return query($query);
}

?>