 <?php
	require 'functions.php';

	$peralatan = query("SELECT * FROM peralatan_elektronik");
 
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Peralatan</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/style.css">
</head>
<body bgcolor="lightblue"> 
	<h1 align="center">Macam-macam Peralatan Elektronik</h1>
	<p><a href="plus.php">Menambah Data</a></p>
	
	<form action="" method="post">
		<center><input type="text" name="keyword" size="45" autofocus placeholder="Masukan keyword pencarian..." autocomplete="off">
		<button type="submit" name="search">Search!</button></center>
	</form>
	<br>

	<table border="4" cellpadding="9" cellspacing="1" bgcolor="white" width="75%">
			<tr width="25%" align="center">
				<th><h2>No</h2></th>
				<th><h2>Option</h2></th>
				<th><h2>Gambar</h2></th>
				<th><h2>Nama Produk</h2></th>
				<th><h2>Jenis Peralatan</h2></th>
				<th><h2>Merek Perusahaan</h2></th>
				<th><h2>Harga</h2></th>
			</tr>

		<?php $no = 1; ?>
		<?php foreach ($peralatan as $per): ?>

			<tr>
				<td align ="center"><?php echo $no++; ?></td>
				<td>
					<a href="update.php?id=<?=$per['id'];?>">Edit</a>
					<a href="delete.php?id=<?=$per['id'];?>" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
				</td>
				<td align ="center"><img src="assets/img/<?php echo $per['gambar'] ?>" width = "100px"></td>
				<td align ="center"><?php echo $per["nama"] ?></td>
				<td align ="center"><?php echo $per["jenis"] ?></td>
				<td align ="center"><?php echo $per["merek"] ?></td>
				<td align ="center"><?php echo $per["harga"] ?></td>
			</tr>
		<?php endforeach; ?>
	</table>
</body>
</html> 