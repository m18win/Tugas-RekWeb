<?php
require 'functions.php';
 $peralatan = query("SELECT * FROM peralatan_elektronik");


if(isset($_POST["search"])) {
	$peralatan = search($_POST["keyword"]);
}

if (isset($_POST['submit'])) {
	if ($_POST['username'] == 'admin' && $_POST['password'] == 'admin') {
		header("location: index.php");
		exit;
	} else {
		$nValid = true;
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>User</title>
</head>
	<style>
		.container {
			border: 1px solid black;
			text-align: center;
			font-size: 20px;
			background-color : aqua;
			margin-left: 600px;
            margin-right: 600px;
		}
		.tombol {
			width: 60px;
			height: 20px;
			background-color: yellow;
			border-radius: 20px;
			text-align: center;
			margin: auto;
		}
	</style>
<body bgcolor="lightblue">
	<center><h2>Macam-macam Peralatan Elektronik</h2></center>
	<form action="" method="post">
		<div class="tombol">
		<center><a href="akun.php">Login</a></center>
		</div><br><br>
		<center><input type="text" name="keyword" size="45" autofocus placeholder="Masukan keyword pencarian..." autocomplete="off">
		<button type="submit" name="search">Search!</button></center>
	</form>
	<br>
 <div class="container">
 			<?php foreach ($peralatan as $per) : ?>
        <div class="content">
           <div class="gambar">
                   <p><img src="assets/img/<?= $per['gambar']; ?>" width="100px">
           </div>
            <p class="nama">
				<a href="profile.php?id=<?= $per['id']; ?>"><?= $per['nama']; ?></a>
			</p>
			<p><?= $per['jenis']; ?></p>
			<?php endforeach; ?>
        </div>
 </div>
</body>
</html>