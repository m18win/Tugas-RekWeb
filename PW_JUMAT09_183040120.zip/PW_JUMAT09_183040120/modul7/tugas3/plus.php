<?php  

require 'functions.php';

if (isset($_POST["submit"])){
    if (plus($_POST) > 0){
        echo "<script>
                alert('Data berhasil ditambah!'); 
                document.location.href = 'index.php';
            </script>";
    }else{
        echo"<script>
                alert('Data gagal ditambah!');
                document.location.href = 'index.php';
            </script>";
    }
}

?>
<!DOCTYPE html>
<html>
<head>
  <title>Plus</title>
</head>
<body bgcolor="lightblue">
  <h1>Menambah Data</h1>
    <div>
      <form action="" method="post">
        <div>
            <div>
                <label for="nama">Nama</label><br>
                <input type="text" name="nama" id="nama"><br><br>
            </div>
            <div>
                <label for="jenis">Jenis</label><br>
                <input type="text" name="jenis" id="jenis"><br><br>
            </div>
            <div>
                <label for="merek">Merek</label><br>
                <input type="text" name="merek" id="merek"><br><br>
            </div>
            <div>
                <label for="harga">Harga</label><br>
                <input type="text" name="harga" id="harga"><br><br>
            </div>
            <div>
                <label for="gambar">Gambar</label><br>
                <input type="text" name="gambar" id="gambar"><br><br>
            </div>
            <button type="submit" name="send">Send</button>
            <button><a href="index.php">Kembali</a></button>
        </div>
      </form>
    </div>
</body>
</html>