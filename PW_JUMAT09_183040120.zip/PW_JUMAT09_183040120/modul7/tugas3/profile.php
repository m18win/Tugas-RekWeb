<?php
if(!isset($_GET['id'])) {
	header("Location: index.php");
	exit;
}

require 'functions.php';
$id = $_GET['id'];

$per = query("SELECT * FROM peralatan_elektronik WHERE id = $id")[0];
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>NRP</title>
</head>
<style> 

</style>
<body bgcolor="lightblue">
<h1>Keterangan</h1>
   <div class="content">

        <div class="gambar">
            <p><img src="assets/img/<?= $per['gambar']; ?>">
        </div>

		<div class="desc">
            <p class="nama"><?= $per['nama']; ?></p>
			<p><?= $per['merek']; ?></p>
			<p><?= $per['jenis']; ?>, <?= $per['harga']; ?></p>
			<p><a href="login.php">Kembali</a></p>
		</div>

   </div>
</body>
</html>