<?php

require 'functions.php';

$id = $_GET["id"];
$per = query("SELECT * FROM peralatan_elektronik WHERE id = $id")[0];

if(isset($_POST['submit'])){
    if(update($_POST) > 0 ){
        print "<script>
            alert('Data berhasil diupdate!');
            document.location.href = 'index.php';
            </script>";
    }else{
        print "<script>
            alert('Data gagal diupdate!');
            document.location.href = 'index.php';
            </script>";
    }
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Update</title>
</head>
<body>
	<h1>Mengubah Data</h1>
    <form action="" method="post">
        <input type="hidden" name="id" value="<?=$per["id"];?>">

        <label for="nama">Nama : </label><br>
        <input type="text" name="nama" id="nama" value="<?=$per['nama'];?>" required><br>

        <label for="jenis">Jenis : </label><br>
        <input type="text" name="jenis" id="jenis" value="<?=$per['jenis'];?>" required><br>

        <label for="merek">Merek : </label><br>
        <input type="textarea" name="merek" id="merek" value="<?=$per['merek'];?>" required><br>

        <label for="harga">Harga : </label><br>
        <input type="text" name="harga" id="harga" value="<?=$per['harga'];?>" required><br>

        <label for="gambar">Gambar : </label><br>
        <input type="text" name="gambar" id="gambar" value="<?=$per['gambar'];?>" required><br><br>
        <button type="submit" name="submit">Perbaharui</button>
    </form>
</body>
</html>