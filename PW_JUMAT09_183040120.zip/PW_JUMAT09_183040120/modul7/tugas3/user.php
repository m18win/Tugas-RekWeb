<?php
require 'functions.php';
 $peralatan = query("SELECT * FROM peralatan_elektronik");

 if( isset($_POST['cari'])) {
 	$peralatan = cari($_POST['keyword']);
 }
 if(isset($_POST['submit'])) {
 	if ($_POST['username'] == 'admin' && $_POST['password'] == 'admin') {
 		header("location: indexH.php");
 		exit;
 	}else{
 		$nValid = true;
 	}
 }
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>User</title>
</head>
	<style>
		.container {text-align: center;}
	</style>
<body bgcolor="lightblue">
	<center><h2>Macam-macam Peralatan Elektronik</h2></center>
	<form action="" method="post">
		<div class="Login">
          <center><a href="admin.php">Login sebagai Admin</a></center>
            </div>
            <br><br>
            <center><input type="text" name="keyword" size="45" autofocus placeholder="Masukan keyword pencarian..." autocomplete="off">
            <button type="submit" name="search">Search</button></center>
	</form>
	<br>
 <div class="container">
 			<?php foreach ($peralatan as $per) : ?>
        <div class="content">
           <div class="gambar">
                   <p><img src="assets/img/<?= $per['gambar']; ?>" width="100px">
           </div>
            <p class="nama">
				<a href="profileH.php?id=<?= $per['id']; ?>"><?= $per['nama']; ?></a>
			</p>
			<p><?= $per['merek']; ?></p>
			<?php endforeach; ?>
        </div>
 </div>
</body>
</html>